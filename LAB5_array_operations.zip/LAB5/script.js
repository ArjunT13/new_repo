const arr = []
const arr3 = []
var i=0;
var j=0;
const arr1 = ["Hello", "World", "Arjun"]

function add_element()
{
    arr[i] = document.getElementById("str").value;  
    document.getElementById("array").innerHTML = "Array: "+arr;
    i++;
}

function display(){
    document.getElementById("result").innerHTML = "Result: "+arr;
}
function reverse(){
    document.getElementById("result").innerHTML = "Result: "+arr.reverse();
}

function sort(){
    var flg=0;
    for(let i=0; i<arr.length; i++){
        if(typeof arr[i] == "string"){
            flg=1;
        }
    }
    if(flg==1) document.getElementById("result").innerHTML = "Result: "+arr.sort();
    else
    document.getElementById("result").innerHTML = "Result: "+arr.sort(function(a, b){return a-b});
}

function check(ele) {
    return ele == document.getElementById("searchele").value;
}
function search(){
    var ele = document.getElementById("searchele").value;
    document.getElementById("resultsearch").innerHTML = "Element Found: "+Boolean(arr.find(check));
}

function BinarySearch(){
    var ele = document.getElementById("searchele").value;
    let start=0, end=arr.length-1, flg=0;
    while (start<=end){

        let mid=Math.floor((start + end)/2);
        if (arr[mid]===ele) {
            flg=1;
            break;
        }
        else if (arr[mid] < ele)
             start = mid + 1;
        else
             end = mid - 1;
    }
    if(flg==1) document.getElementById("resultsearch").innerHTML = "Element Found: "+true;
    else document.getElementById("resultsearch").innerHTML = "Element Found: "+false;
}

function remove(){
    document.getElementById("result").innerHTML = "Popped Element is: "+arr.pop();
}

function concat(){
    document.getElementById("resultcon").innerHTML = "Concatenated Array: "+arr.concat(arr1);
}

function BubbleSort(){
    var nums=arr.map(function(str){
        return parseInt(str);
    });
    for(var i = 0; i < nums.length; i++){
    
        for(var j = 0; j < ( nums.length - i -1 ); j++){

          if(nums[j] > nums[j+1]){
            var temp = nums[j]
            nums[j] = nums[j + 1]
            nums[j+1] = temp
          }
        }
      }
    document.getElementById("resultsort").innerHTML = "Sorted Array: "+nums;
}

function partition(array1, low, high)
{
    let temp;
    let pivot = array1[high];

    let i = (low - 1);
    for (let j = low; j <= high - 1; j++) {
        if (array1[j] <= pivot) {
            i++;
            temp = array1[i];
            array1[i] = array1[j];
            array1[j] = temp;
        }
    }

    temp = array1[i + 1];
    array1[i + 1] = array1[high];
    array1[high] = temp;

    return i + 1;
}

function Quicksort()
{
    var nums=arr.map(function(str){
        return parseInt(str);
    });
    let temp1 = new Array(nums.length);
    let l = 0;
    let h = arr.length -1;
    temp1.fill(0);
    let top = -1;
    temp1[++top] = l;
    temp1[++top] = h;
    while (top >= 0) {
        h = temp1[top--];
        l = temp1[top--];

        let p = partition(nums, l, h);

        if (p - 1 > l) {
            temp1[++top] = l;
            temp1[++top] = p - 1;
        }

        if (p + 1 < h) {
            temp1[++top] = p + 1;
            temp1[++top] = h;
        }
    }
    document.getElementById("resultqsort").innerHTML = "Sorted Array: "+nums;
}

/*function partition(arr, start, end) {
    const pivotValue = arr[start]
    let swapIndex = start
    for (let i = start + 1; i <= end; i++) {
      if (pivotValue > arr[i]) {
        swapIndex++
        if (i !== swapIndex) {
          // SWAP
          ;[arr[i], arr[swapIndex]] = [arr[swapIndex], arr[i]]
        }
      }
    }
    if (swapIndex !== start) {
      // Swap pivot into correct place
      ;[arr[swapIndex], arr[start]] = [arr[start], arr[swapIndex]]
    }
    return swapIndex
}

function Quicksort(arr, start = 0, end = arr.length - 1) {
    // Base case
    if (start >= end) return
    let pivotIndex = partition(arr, start, end)
    // Left
    Quicksort(arr, start, pivotIndex - 1)
    // Right
    Quicksort(arr, pivotIndex + 1, end)
    return arr
}

function Quicksort(array){
    if (array.length < 2){
       return array;
    }
    let pivot_element = array[array.length - 1]
    let left_sub_array = [];
    let right_sub_array = [];
    for (let i = 0; i < array.length - 1; i++){
       if (array[i] < pivot_element) {
          left_sub_array.push(array[i])
       } else {
          right_sub_array.push(array[i])
       }
    }
    return [...Quicksort(left_sub_array), pivot_element, ...Quicksort(right_sub_array)];
}*/