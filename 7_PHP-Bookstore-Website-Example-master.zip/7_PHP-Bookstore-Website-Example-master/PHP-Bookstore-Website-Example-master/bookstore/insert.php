<?php
    $servername = "localhost";
    $username = "root";
    $password = "";

    $conn = new mysqli($servername, $username, $password);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    } 

    $sql = "USE bookstore";
    $conn->query($sql);
?>

<!DOCTYPE html>
    <head>
        <title>Add New Book</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
        <link rel="stylesheet" href="./insert.css?php echo time(); ?>">
    </head>
    <body>
        <div id="contextbox"><h2>Insert New Book</h2></div>
       <form method="POST">
        <table class="table">
                <tr>
                    <td style="font-size:18px; vertical-align:middle;">Book ID.</td>
                    <td><input type='number' name='BookID'></td>
                </tr>
                <tr>
                    <td style="font-size:18px; vertical-align:middle;">Book Title</td>
                    <td><input name='BookTitle'></td>
                </tr>
                <tr>
                    <td style="font-size:18px; vertical-align:middle;">Book Author</td>
                    <td><input name='Author'></td>
                </tr>
                <tr>
                    <td style="font-size:18px; vertical-align:middle;">Price</td>
                    <td><input type="number" name='Price'></td>
                </tr>
                <tr>
                    <td style="font-size:18px; vertical-align:middle;">ISBN</td>
                    <td><input name='ISBN'></td>
                </tr>
                <tr>
                    <td style="font-size:18px; vertical-align:middle;">Book type</td>
                    <td><input name='Type'></td>
                </tr>
                <tr>
                    <td style="font-size:18px; vertical-align:middle;">Book Cover URL</td>
                    <td><input name='Image'></td>
                </tr>
            </table>
            <button name="Insert" type="submit" style="margin-left:500px; font-size: 18px;">Insert</button>
        </form>
    </body>
</html>

<?Php
if(isset($_POST['Insert']))
{

    $BookID = $_POST['BookID'];
	$BookTitle = $_POST['BookTitle'];
    $ISBN = $_POST['ISBN'];
    $Price = $_POST['Price'];
    $Author = $_POST['Author'];
    $Type = $_POST['Type'];
    $Image = $_POST['Image'];

    $sql = "INSERT into book (BookID, BookTitle, ISBN, Price, Author, Type, Image) VALUES ('$BookID', '$BookTitle', '$ISBN', '$Price', '$Author', '$Type', '$Image')" ;
    $result = $conn->query($sql);

    if ($result == TRUE)
    {
        header("Location: index.php");
    }
    else
    {
        echo "Error in updating record.";
    }
}
?>

