<?php
    $servername = "localhost";
    $username = "root";
    $password = "";

    $conn = new mysqli($servername, $username, $password);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    } 

    $sql = "USE bookstore";
    $conn->query($sql);

    $BookID = $_GET['BookID'];

    $sql = "DELETE FROM Book where BookID=".$BookID;
    $result = $conn->query($sql);

    header("Location: index.php");

?>
