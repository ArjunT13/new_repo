window.onload=function() {
    var fname = document.getElementById("fnm");
    var email = document.getElementById("email");
    var lname = document.getElementById("lnm");
    var mob = document.getElementById("ph");
    var password = document.getElementById("pass");
    var address = document.getElementById("adr");
    var button = document.getElementById("but");
    var regPsd = /^(?=.*\d)(?=.*[!@#$%^&*])(?=.*[a-z])(?=.*[A-Z]).{6,}$/;
    var regEmail=/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/; 
    var regPhone=/^\d{10}$/;									
    var regName = /[a-zA-Z]+$/;								 
    var i=0, j=0, k=0, l=0, m=0;

    fname.addEventListener('keydown' , function(){
        if(this.value.length < 6 || !regName.test(this.value)) {
            this.classList.add('invalid');
            error.classList.add('show'); 
            but.classList.add('Disabled');
        } else {
            this.classList.remove('invalid');
            error.classList.remove('show');
        }
    });

    lname.addEventListener('keydown' , function(){
        if(this.value.length < 6 || !regName.test(this.value)) {
            this.classList.add('invalid');
            errorl.classList.add('show'); 
            //but.classList.add('Disabled');
            document.getElementById("but").disabled = true;
        } else {
            this.classList.remove('invalid');
            errorl.classList.remove('show');
            document.getElementById("but").disabled = false;
        }
    });

    mob.addEventListener('keydown' , function(){
        if(!regPhone.test(this.value)) {
            this.classList.add('invalid');
            errorph.classList.add('show'); 
        } else {
            this.classList.remove('invalid');
            errorph.classList.remove('show');
        }
    });

    email.addEventListener('keydown' , function(){
        if(!regEmail.test(this.value)) {
            this.classList.add('invalid');
            errore.classList.add('show'); 
        } else {
            this.classList.remove('invalid');
            errore.classList.remove('show');
        }
    });

    password.addEventListener('keydown' , function(){
        if(this.value.length < 6 || !regPsd.test(this.value)) {
            this.classList.add('invalid');
            errorp.classList.add('show'); 
        } else {
            this.classList.remove('invalid');
            errorp.classList.remove('show');
        }
    });

    address.addEventListener('keydown' , function(){
        if(this.value.length == 0) {
            this.classList.add('invalid');
            errorad.classList.add('show'); 
        } else {
            this.classList.remove('invalid');
            errorad.classList.remove('show');
        }
    });

}