<?php

    include 'initial.php';

?>

<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>Registration Page</title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link rel='stylesheet' type='text/css' media='screen' href='style.css'>
</head>
<body>
    <header>Registration Form </header>
    <form class="form" name="RegistrationForm" method="post">
        <div class="input-box">
            <label>First Name</label>
            <input style="padding:10px; font-size:18px; vertical-align:middle; height:25px;" type="text" placeholder="Enter first name" id="fnm" name="fnm" required />
            <div id="error">
            Invalid Name
            </div>
        </div>

        <div class="input-box">
            <label>Last Name</label>
            <input style="padding:10px; font-size:18px; vertical-align:middle; height:25px;" type="text" placeholder="Enter last name" id="lnm" name="lnm" required />
            <div id="errorl">
            Invalid Name
            </div>
        </div>

        <div class="input-box">
            <label>Email Address</label>
            <input style="padding:10px; font-size:18px; vertical-align:middle; height:25px;" type="text" placeholder="Enter email address" name="email" id="email" required />
            <div id="errore">
            Invalid Email.
            </div>
        </div>

        <div class="input-box">
            <label>Password</label>
            <input style="padding:10px; font-size:18px; vertical-align:middle; height:25px;" type="password" placeholder="Enter password" name="pass" id="pass" required />
            <div id="errorp">
            Invalid Password.
            </div>
        </div>

        <div class="input-box">
            <label>Address</label>
            <input style="padding:10px; font-size:18px; vertical-align:middle; height:25px;" type="text" placeholder="Enter your address" name="adr" id="adr" required />
            <div id="errorad">
            Invalid Address.
            </div>
        </div>

        <div class="input-box">
            <label>Phone Number</label>
            <input style="padding:10px; font-size:18px; vertical-align:middle; height:25px;" type="text" placeholder="Enter your mobile no." name="ph" id="ph" required />
            <div id="errorph">
            Invalid Phone Number.
            </div>
        </div>
        <br>
        <button name="sub" id="but" type="submit">Submit</button>
    </form>
    <br> <br>
    <table class="table">
        <thead>
            <th style="font-size:18px; padding: 10px">First Name</th>
            <th style="font-size:18px; padding: 10px">Last Name</th>
            <th style="font-size:18px; padding: 10px">Email</th>
            <th style="font-size:18px; padding: 10px">Address</th>
            <th style="font-size:18px; padding: 10px">Phone No.</th>
            <th style="font-size:18px; padding: 10px">Action</th>
        </thead>
        <?php
            $sql = "SELECT * FROM registration";
            $result = $link->query($sql);
            $num = mysqli_num_rows ( $result );
            for ($x = 0; $x < $num; $x++) { 
                $row = mysqli_fetch_array($result); ?>
                <tr >
                    <td style="font-size:18px; vertical-align:middle; padding: 10px"><?php echo $row['fname']; ?></td>
                    <td style="font-size:18px; vertical-align:middle; padding: 10px"><?php echo $row['lname']; ?></td>
                    <td style="font-size:18px; vertical-align:middle; padding: 10px"><?php echo $row['email']; ?> </td>
                    <td style="font-size:18px; vertical-align:middle; padding: 10px"><?php echo $row['addr']; ?></td>
                    <td style="font-size:18px; vertical-align:middle; padding: 10px"><?php echo $row['ph']; ?></td>
                    <td style="font-size:16px;">
                        <a href="
                        Update.php?fname=<?php echo $row['fname']; ?>&table=registration">Update</a>
                        ||
                        <a href="Delete.php?fname=<?php echo $row['fname']; ?>&table=registration">Delete</a>
                    </td>
                </tr>
        <?php } ?>
    </table>

    

    <script src='validate.js'></script>    

</body>

<?Php
if(isset($_POST['sub']))
{
    $fname = $_POST['fnm'];
    $lname = $_POST['lnm'];
    $email = $_POST['email'];
    $Ph = $_POST['ph'];
    $addr = $_POST['adr'];
    $pass = $_POST['pass'];

    $sql = "INSERT into registration (fname, lname, email, pass, ph, addr) values('$fname', '$lname', '$email', '$pass', '$Ph', '$addr')" ;
    $result = $link->query($sql);

    if ($result == TRUE)
    {
        header("Location: index.php");
        echo "Data Entered Successfully.";
    }
    else
    {
        echo "Error in updating record.";
    }
}
?>
</html>