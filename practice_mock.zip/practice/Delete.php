<?php

    include "initial.php";

    $fname = $_GET['fname'];
    $table = $_GET['table'];

    $sql = "DELETE FROM ".$table." where fname='".$fname."'";
    $result = $link->query($sql);

    header("Location: index.php");

?>
