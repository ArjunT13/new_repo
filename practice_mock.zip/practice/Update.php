
<?php
    include "initial.php";

    $fname = $_GET['fname'];
    $table = $_GET['table'];

    
    $sql = "SELECT * FROM ".$table." where fname='".$fname."'";
    $result = $link->query($sql);
    $row = mysqli_fetch_array($result);
?>

<!DOCTYPE html>
    <head>
        <title>Document</title>
        <link rel='stylesheet' type='text/css' media='screen' href='style.css'>
        
    </head>
    <body>
        <div class="container">
       <h2>User Update Form</h2>   

       <form method="POST">
        <table class="table">
                <tr style="padding:10px; font-size:18px;">
                    <td style="font-size:18px; vertical-align:middle; padding:10px;">First Name</td>
                    <td><input style="padding:10px; font-size:18px; vertical-align:middle; height:25px;" id="nm" name='fname' value='<?php echo $row['fname'];?>'></td>
                </tr>
                <tr>
                    <td style="font-size:18px; vertical-align:middle; padding:10px;">Last Name</td>
                    <td><input style="padding:10px; font-size:18px; vertical-align:middle; height:25px;" id="lnm" name='lname' value='<?php echo $row['lname'];?>'></td>
                </tr>

                <tr>
                    <td style="font-size:18px; vertical-align:middle; padding:10px;">Email</td>
                    <td><input style="padding:10px; font-size:18px; vertical-align:middle; height:25px;" id="em" name='email' value='<?php echo $row['email'];?>'></td>
                </tr>

                <tr>
                    <td style="font-size:18px; vertical-align:middle; padding:10px;">Password</td>
                    <td><input style="padding:10px; font-size:18px; vertical-align:middle; height:25px;" id="ps" name='pass' value='<?php echo $row['pass'];?>'></td>
                </tr>

                <tr>
                    <td style="font-size:18px; vertical-align:middle; padding:10px;">Address</td>
                    <td><input style="padding:10px; font-size:18px; vertical-align:middle; height:25px;" id="ad" name='addr' value='<?php echo $row['addr'];?>'></td>
                </tr>

                <tr>
                    <td style="font-size:18px; vertical-align:middle; padding:10px;">Mobile number</td>
                    <td><input style="padding:10px; font-size:18px; vertical-align:middle; height:25px;" id="ph" name='ph' value='<?php echo $row['ph'];?>'></td>
                </tr>
            </table>

            <button id="up" name="update" type="submit" style="margin-left:500px; font-size: 18px;">Update</button>
        </form>
    </body>
</html>

<?php
if(isset($_POST['update']))
{
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $email = $_POST['email'];
    $Ph = $_POST['ph'];
    $addr = $_POST['addr'];
    $pass = $_POST['pass'];

    $sql = "UPDATE ".$table." SET fname='$fname', lname='$lname', email='$email', ph='$Ph', addr='$addr', pass='$pass' WHERE fname='$fname'";
    $result = $link->query($sql);
    

    if ($result == TRUE)
    {
        header("Location: index.php");
    }
    else
    {
        echo "Error in updating record.";
    }
}
?>