package com.springboot_bill.electricity_bill;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;

@SpringBootApplication (exclude = {DataSourceAutoConfiguration.class})
public class ElectricityBillApplication {

	public static void main(String[] args) {
		SpringApplication.run(ElectricityBillApplication.class, args);
	}
	
}
