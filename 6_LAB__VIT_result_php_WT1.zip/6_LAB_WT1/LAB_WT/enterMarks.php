<!DOCTYPE html>
<html>

<head>
    <title>Student Results</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link rel="stylesheet" type="text/css" href="style2.css">

</head>


<style>
    body {
        font-family: 'Roboto', sans-serif !important;
        background-color:cadetblue;
    }

    h1 {
        font-size: 35px;
        color: #000;
        text-transform: uppercase;
        font-weight: 600;
        text-align: center;
        margin: 3vw 0 ;
    }

    #resultForm {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        gap: 0.8vw;
        width: 60%;
        margin: 3.5vw 0;
        background: rgba(255, 255, 255, 0.25);
        box-shadow: 0 8px 32px 0 rgba(0, 0, 0, 0.37);
        backdrop-filter: blur(4px);
        -webkit-backdrop-filter: blur(4px);
        border-radius: 10px;
        padding: 2vw 4vw;
        color: #000 !important;
        border: 1px solid rgba(255, 255, 255, 0.18);
    }

    #resultForm input {
        border-radius: 0.5vw;
        width: 20vw;
        height: 2.5vw;
        line-height: 2.2vw;
        font-size: 1.6vw;
        padding: .5vw 0.5vw;
        border: 1px solid #000;
    }

    #resultForm input[type="submit"] {
        box-sizing: border-box;
        background-color: black;
        border-radius: 0.5vw;
        width: 15vw;
        height: 3vw;
        font-size: 1.75vw !important;
        color: #fff;
        text-decoration: none;
        transition: all 0.35s ease-in-out;
        cursor: pointer;
        border: 0.5px solid rgba(255, 255, 255, 0.4) !important;
    }

    #resultForm input[type="submit"]:hover {
        box-shadow: 1px 5px 5px 0 rgba(0, 0, 0, 0.37);
        transition: all 0.25s ease-in-out;
        transform: scale(1.03, 1.03) !important;
    }

    hr {
        border: 0.5px solid rgba(0, 0, 0, .4);
        ;
        background-color: rgba(0, 0, 0, .4);
        border-radius: 70%;
        width: 80%;
        height: 1px;
    }
</style>


<body>
    <h1>Student Results</h1>
    <center>
        <form id="resultForm">

            <label for="pr_no">PR Number : </label>
            <input type="text" id="pr_no" name="pr_no"><br>
            <hr><br>



            <label for="name">Name : </label>
            <input type="text" id="name" name="name"><br>
            <hr><br>




            <label for="mse_marks">Compiler Design MSE Marks : </label>
            <input type="text" id="mse_CC" name="mse_CC"><br>
            <hr><br>



            <label for="mse_marks">Web Technology MSE Marks : </label>
            <input type="text" id="mse_WT" name="mse_WT"><br>
            <hr><br>



            <label for="mse_marks">Design and Analysis of Algorithms MSE Marks : </label>
            <input type="text" id="mse_DAA" name="mse_DAA"><br>
            <hr><br>



            <label for="mse_marks">Cloud Coumputing MSE Marks : </label>
            <input type="text" id="mse_CD" name="mse_CD"><br>
            <hr><br>



            <label for="mse_marks">Compiler Design ESE Marks : </label>
            <input type="text" id="ese_CC" name="ese_CC"><br>
            <hr><br>



            <label for="mse_marks">Web Technology ESE Marks : </label>
            <input type="text" id="ese_WT" name="ese_WT"><br>
            <hr><br>



            <label for="mse_marks">Design and Analysis of Algorithms ESE Marks : </label>
            <input type="text" id="ese_DAA" name="ese_DAA"><br>
            <hr><br>



            <label for="mse_marks">Cloud Coumputing ESE Marks : </label>
            <input type="text" id="ese_CD" name="ese_CD"><br>
            <hr><br>



            <input type="submit" value="Submit" />
        </form>
    </center>

    <script>
        $(document).ready(function() {
            $('#resultForm').submit(function(event) {
                // Stop the form from submitting normally
                event.preventDefault();

                // Get the form data
                var formData = $(this).serialize();

                // Send the data to the server using AJAX
                $.ajax({
                    type: 'POST',
                    url: 'enterDB.php',
                    data: formData,
                    success: function(response) {
                        alert(response);
                        header("Location: index.php")
                    },
                    error: function() {
                        alert('Error: Unable to submit results.');
                    }
                });
            });
        });
    </script>
</body>

</html>