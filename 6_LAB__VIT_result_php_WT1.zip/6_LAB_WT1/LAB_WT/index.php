<!DOCTYPE html>
<html>

<head>
    <title>Student Results</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link rel="stylesheet" type="text/css" href="style2.css">

</head>


<style>
    body {
        font-family: 'Roboto', sans-serif !important;
        background-color:cadetblue;
    }
    #content-box{
        display: flex;
        flex-direction: row;
        align-items: center;
        align-content: space-around;
        flex-wrap: wrap;
        justify-content: center;
    }

    h1 {
        font-size: 35px;
        color: #000;
        text-transform: uppercase;
        font-weight: 600;
        text-align: center;
        margin: 3vw 0 ;
    }

    #marks, #search {
        box-sizing: border-box;
        background-color: black;
        border-radius: 0.5vw;
        width: 15vw;
        height: 5vw;
        font-size: 1.75vw !important;
        color:aqua;
        text-decoration: none;
        transition: all 0.35s ease-in-out;
        cursor: pointer;
        border: 0.5px solid rgba(255, 255, 255, 0.4) !important;
    }

    #marks:hover, #search:hover {
        box-shadow: 1px 5px 5px 0 rgba(0, 0, 0, 0.37);
        transition: all 0.25s ease-in-out;
        transform: scale(1.03, 1.03) !important;
    }

    hr {
        border: 0.5px solid rgba(0, 0, 0, .4);
        background-color: rgba(0, 0, 0, .4);
        border-radius: 70%;
        width: 80%;
        height: 1px;
    }
</style>


<body>
    <h1>Student Results</h1>
    <center>
        <img src="img.jpg" style="width: 15%; height:25%; border-radius:50%;">
        <br> <br>
        <div id="content-box">
            <form action="" method="post" name="normal">
                <input type="submit" name="marks" id="marks" style="margin-right:2vw;" value="Enter Marks">
            </form>
            <form action="" method="post" name="normal">
                <input type="submit" id="search" name="search" value="Search Records">
            </form>
        </div>
    </center>
</body>
<?php 
if(isset($_POST['marks'])){
    header("Location: enterMarks.php");
}
if(isset($_POST['search'])){
    header("Location: search.php");
}
?>

</html>