<?php
// Get the form data
$pr_no = $_GET['pr_no'];
// Create a connection to the database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mydb";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection not done: " . $conn->connect_error);
}

// Insert the data into the database
$sql = "SELECT * FROM student_results WHERE pr_no=$pr_no";
$result = mysqli_query($conn, $sql);



$row = mysqli_fetch_assoc($result);
if (mysqli_num_rows($result) === 0) {
  echo 'No Result';
} 
else{
  header('Content-type: application/json');
echo json_encode($row);
}

// $data = array();
// while ($row = $result->fetch_assoc()) {
//     $data[] = $row;
// }

// Close the connection
$conn->close();

// Return the results in JSON format

?>