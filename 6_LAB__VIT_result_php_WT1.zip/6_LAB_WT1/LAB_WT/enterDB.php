<?php
$pr_no = $_POST['pr_no'];
$name_ = $_POST['name'];
// echo gettype($name_);
$mse_CC = $_POST['mse_CC'];
$ese_CC = $_POST['ese_CC'];
$mse_WT = $_POST['mse_WT'];
$ese_WT = $_POST['ese_WT'];
$mse_DAA = $_POST['mse_DAA'];
$ese_DAA = $_POST['ese_DAA'];
$mse_CD = $_POST['mse_CD'];
$ese_CD = $_POST['ese_CD'];

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mydb";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection not done: " . $conn->connect_error);
}

$sql = "INSERT INTO student_results (pr_no, name, mse_CC, mse_WT, mse_DAA, mse_CD, ese_CC, ese_WT, ese_DAA, ese_CD) VALUES ($pr_no, '$name_', $mse_CC, $mse_WT, $mse_DAA, $mse_CD, $ese_CC, $ese_WT, $ese_DAA, $ese_CD);";
// echo $sql;
if ($conn->query($sql) === TRUE) {
    echo "Results added successfully!";
    // header("Location: displayResult.php");
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
